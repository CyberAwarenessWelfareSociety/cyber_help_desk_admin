import { useContext, useState } from "react";
import styles from "./Signup.module.css";
import api from "../../Utils/api";
import toast from "react-hot-toast";
import Cookies from "js-cookie";
import { UserContext } from "../../context/contextAPI";
import { useNavigate } from "react-router-dom";
import { FaEye, FaEyeSlash } from "react-icons/fa"; // Add this import

export default function Login() {
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false); // toggle state
  const { setUser, setToken } = useContext(UserContext);
  const navigate = useNavigate();

 // Declare toastId outside the function so it persists
let toastId;

const handleLoginSubmit = async (e) => {
  e.preventDefault();

  if (!mobile || mobile.length < 10) {
    // dismiss previous toast if exists
    if (toastId) toast.dismiss(toastId);
    toastId = toast.error("Please enter a valid 10 digit mobile number");
    return;
  }

  if (!password) {
    if (toastId) toast.dismiss(toastId);
    toastId = toast.error("Please enter your password");
    return;
  }

  try {
    const response = await api.post("/login", {
      phone_no: mobile,
      password,
    });

    console.log("Login response:", response);

    if (response.status === 200) {
      const token = response.data?.token;
      const apiKeys = response.data?.apiKeys[0];

      if (token) {
        Cookies.set("token", token, { expires: 7 });
        Cookies.set("apiKeys", apiKeys, { expires: 7 });
      }

      setUser(response.data?.client);
      setToken(token);
      localStorage.setItem("user", JSON.stringify(response.data?.client));

      if (toastId) toast.dismiss(toastId);
      toastId = toast.success("Login successful");

      navigate("/dashboard", { replace: true });

      setMobile("");
      setPassword("");
    }
  } catch (error) {
    console.error("Login error:", error);

    const errorMessage =
      error?.response?.data?.message ||
      error?.response?.data?.error ||
      "Something went wrong. Please try again later.";

    if (toastId) toast.dismiss(toastId);
    toastId = toast.error(errorMessage);
  }
};


  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <div className={styles.leftPane}>
          <h1>Hello QIK! 👋</h1>
          <p>
            Skip repetitive and manual sales-marketing tasks.
            <br />
            Get highly productive through automation and save tons of time!
          </p>
          <footer>© 2025 QIK Tracking Solution. All rights reserved.</footer>
        </div>
        <div className={styles.rightPane}>
          <form
            className={`${styles.form} ${styles.centeredForm}`}
            onSubmit={handleLoginSubmit}
            noValidate
          >
            <h2>Login</h2>

            <label htmlFor="mobileNumber">Mobile Number</label>
            <input
              id="mobileNumber"
              name="mobileNumber"
              type="tel"
              required
              placeholder="Enter 10-digit Mobile Number"
              value={mobile}
              maxLength={10}
              autoComplete="tel"
              onChange={(e) =>
                setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))
              }
            />

            <label htmlFor="password">Password</label>
            <div className={styles.passwordWrapper}>
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                autoComplete="current-password"
              />
              <span
                className={styles.eyeIcon}
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </span>
            </div>

            <button type="submit" className={styles.btnGreen}>
              Login
            </button>

            <div style={{ marginTop: "12px", textAlign: "right" }}>
              <button
                type="button"
                onClick={() => navigate("/forgot-password")}
                className={styles.forgotBtn}
              >
                Forgot password?
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
